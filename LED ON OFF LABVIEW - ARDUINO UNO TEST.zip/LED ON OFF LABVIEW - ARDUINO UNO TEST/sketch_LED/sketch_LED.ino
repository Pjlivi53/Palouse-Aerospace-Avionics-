  int portLED = 13; //led output
  char labview = 0;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);

  /*Declare pin 12 as output*/
  pinMode(portLED, OUTPUT); // if using sensors, you can use INPUT

}

void loop() {
  // put your main code here, to run repeatedly:
  if (Serial.available() > 0){

    /* Any entered values will be stored in labview */
    labview = Serial.read();
    if(labview == '1'){
      digitalWrite(portLED, HIGH); // If Serial Monitor is 1, Turn on LED
    }
    if (labview == '2'){
      digitalWrite(portLED, LOW);
    }
  }

}
